create table bajaj(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Bajaj Auto.csv' 
INTO TABLE  bajaj
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');

select * from bajaj;
create table Eichermotors(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Eicher Motors.csv' 
INTO TABLE  Eichermotors
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');



# creating a table for heromotocorps
create table heromotocorps(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Hero Motocorp.csv' 
INTO TABLE  heromotocorps
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');


#creating a table for infosys
create table infosys(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Infosys.csv' 
INTO TABLE  infosys
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');

#creating a table for TCS
create table tcs(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/TCS.csv' 
INTO TABLE  tcs
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');

#creating a table for TVSMOTORS
create table tvsmotors(
Date DATE ,
`Open Price` double,
`High Price`double,
`Low Price` double,	
`Close Price` double,
`WAP` double,
`No.of Shares` double,
`No. of Trades` long,
`Total Turnover (Rs.)` long,
`Deliverable Quantity` long,
`% Deli. Qty to Traded Qty` long,
`Spread High-Low` decimal(10,2),
`Spread Close-Open` decimal(10,2)

);

LOAD DATA  INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/TVS Motors.csv' 
INTO TABLE  tvsmotors
FIELDS TERMINATED BY ',' 
#ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@var1, `Open Price`, `High Price`, `Low Price`, `Close Price`, 
`WAP`, `No.of Shares`, `No. of Trades`,
`Total Turnover (Rs.)`,`Deliverable Quantity`,`% Deli. Qty to Traded Qty`,
`Spread High-Low`,`Spread Close-Open`) 
SET Date=str_to_date(@var1,'%e-%M-%Y');

select *from heromotocorps;
create table bajaj1 select Date,`close price` from bajaj;
select * from bajaj1;
alter table bajaj1 add  column `20 DAY MA` double;
alter table bajaj1 add  column `50 DAY MA` double;
#create heromotocorp1


create table heromotocorps1 select Date,`close price` from heromotocorps;
select * from heromotocorps;
alter table heromotocorps add  column `20 DAY MA` double;
alter table heromotocorps add  column `50 DAY MA` double;
# create table tcs1
create table tcs1 select Date,`close price` from tcs;
select * from tcs1;
alter table tcs1 add  column `20 DAY MA` double;
alter table tcs1 add  column `50 DAY MA` double;
#createfor infosys
create table infosys1 select Date,`close price` from infosys;
select * from infosys1;
alter table infosys1 add  column `20 DAY MA` double;
alter table infosys1 add  column `50 DAY MA` double;

#create table for tvsmotors
create table tvsmotors1 select Date,`close price` from tvsmotors;
select * from tvsmotors1;
alter table tvsmotors1 add  column `20 DAY MA` double;
alter table tvsmotors1 add  column `50 DAY MA` double;

#create table for eicher motors
create table eichermotors1 select Date,`close price` from eichermotors;
select * from eichermotors1;
alter table eichermotors1 add  column `20 DAY MA` double;
alter table eichermotors1 add  column `50 DAY MA` double;
select * from bajaj1 order by Date; 

alter table bajaj1 add column rownumber double;

SET SQL_SAFE_UPDATES=0;
update bajaj1 b1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from bajaj1
) tsub 
on 
b1.Date = tsub.Date 
set b1.`rownumber`=tsub.`rownumber1`;

# creating 20 DAY MOVING AVERAGE 
update bajaj1 b1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from bajaj1
 
) tsub 
on 
b1.Date = tsub.Date 
set b1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update bajaj1 b1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from bajaj1
 
) tsub 
on 
b1.Date = tsub.Date 
set b1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;


alter table bajaj1 add column `signal` varchar(250);

############  create buy and sell signalfor bajaj table###########
SET SQL_SAFE_UPDATES=0;

update bajaj1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from bajaj1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;

select count(*) from bajaj1 where `signal`='SELL';












# creating a mastertable 

create table mastertable select Date from bajaj1;

Alter table mastertable add column Bajaj1 long;
Alter table mastertable add column TCS1 long;
Alter table mastertable add column TVS1 long;
Alter table mastertable add column Infosys1 long;
Alter table mastertable add column Eicher1 long;
Alter table mastertable add column Hero1 long;
SET SQL_SAFE_UPDATES=0;
# updating mastertable 
update  mastertable m join
(select`close price` ,Date from bajaj1) b1 on b1.Date = m.Date
set m.Bajaj1= b1.`close price`;

select* from mastertable;
#select * from TVS1;
# update TCS1 column 
update  mastertable m join
(select`close price` ,Date from TCS1) b1 on b1.Date = m.Date
set m.TCS1= b1.`close price`;

#update TVS1 column
update  mastertable m join
(select`close price` ,Date from tvsmotors1) b1 on b1.Date = m.Date
set m.TVS1= b1.`close price`;

#update infosys1
update  mastertable m join
(select`close price` ,Date from infosys1) b1 on b1.Date = m.Date
set m.Infosys1= b1.`close price`;

#update Eicher1
update  mastertable m join
(select`close price` ,Date from eichermotors1) b1 on b1.Date = m.Date
set m.`Eicher1`= b1.`close price`;

#update hero1
update  mastertable m join
(select`close price` ,Date from heromotocorps1) b1 on b1.Date = m.Date
set m.`Hero1`= b1.`close price`;


# finally our mastertable 
select * from mastertable;

#eichermotors1 

select * from eichermotors1;

alter table eichermotors1 add column rownumber double;
SET SQL_SAFE_UPDATES=0;
update eichermotors1 e1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from eichermotors1
) tsub 
on 
e1.Date = tsub.Date 
set e1.`rownumber`=tsub.`rownumber1`;


update eichermotors1 e1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from eichermotors1
 
) tsub 
on 
e1.Date = tsub.Date 
set e1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update eichermotors1 e1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from eichermotors1
 
) tsub 
on 
e1.Date = tsub.Date 
set e1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;

select * from eichermotors1;


alter table eichermotors1 add column `signal` varchar(250);

#generating signal for eichermotors 
#BUY

SET SQL_SAFE_UPDATES=0;

update eichermotors1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from eichermotors1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;

select count(*) from eichermotors1 where `signal`='BUY';


#heromotocorps
select * from heromotocorps1;

alter table heromotocorps1 add column rownumber double;
SET SQL_SAFE_UPDATES=0;
update heromotocorps1 h1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from heromotocorps1
) tsub 
on 
h1.Date = tsub.Date 
set h1.`rownumber`=tsub.`rownumber1`;
alter table heromotocorps1 add  column `20 DAY MA` double;
alter table heromotocorps1 add  column `50 DAY MA` double;

update heromotocorps1 h1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from heromotocorps1
 
) tsub 
on 
h1.Date = tsub.Date 
set h1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update heromotocorps1 h1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from eichermotors1
 
) tsub 
on 
h1.Date = tsub.Date 
set h1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;

select * from heromotocorps1;


alter table heromotocorps1 add column `signal` varchar(250);

#generating signal for heromotocorps1 
SET SQL_SAFE_UPDATES=0;

update heromotocorps1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from heromotocorps1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;
########### setting signals for infosys1 ###########

select * from infosys1;

alter table infosys1 add column rownumber double;
SET SQL_SAFE_UPDATES=0;
update infosys1 s1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from infosys1
) tsub 
on 
s1.Date = tsub.Date 
set s1.`rownumber`=tsub.`rownumber1`;


update infosys1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from infosys1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update infosys1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from infosys1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;

select * from infosys1;


alter table infosys1 add column `signal` varchar(250);

#generating signal for infosys 

SET SQL_SAFE_UPDATES=0;

update infosys1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from infosys1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;

select count(*) from infosys1  where `signal` ='SELL';

##########setting signal for tcs 1 ####################
select * from tcs1;

alter table tcs1 add column rownumber double;
SET SQL_SAFE_UPDATES=0;

update tcs1 s1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from tcs1
) tsub 
on 
s1.Date = tsub.Date 
set s1.`rownumber`=tsub.`rownumber1`;


update tcs1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from tcs1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update tcs1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from tcs1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;

select * from tcs1;


alter table tcs1 add column `signal` varchar(250);

#generating signal for TCS 

SET SQL_SAFE_UPDATES=0;

update tcs1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from tcs1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;

select  count(*) from tcs1 where `signal` = 'SELL' ;

############ generating signals for  tvsmotors1##################

select * from tvsmotors1;

alter table tvsmotors1 add column rownumber double;
SET SQL_SAFE_UPDATES=0;
update tvsmotors1 s1 
join 
(
 SELECT Date,row_number() over( order by Date asc ) as `rownumber1` 
 from tvsmotors1
) tsub 
on 
s1.Date = tsub.Date 
set s1.`rownumber`=tsub.`rownumber1`;


update tvsmotors1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 19 preceding  ) as `20 DAYS MA` 
 from tvsmotors1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`20 DAY MA`=
CASE 
when rownumber >19 then tsub.`20 DAYS MA`
when rownumber <19 then NULL
END;



# CREATING 50 days moving AVERAGE 
update tvsmotors1 s1 
join 
( 
 
 SELECT Date,Avg(`close price`) over( order by Date asc rows 49 preceding  ) as `50 DAYS MA` 
 from tvsmotors1
 
) tsub 
on 
s1.Date = tsub.Date 
set s1.`50 DAY MA`=
CASE 
when rownumber >49 then tsub.`50 DAYS MA`
when rownumber <49 then NULL
END;

select * from tvsmotors1;


alter table tvsmotors1 add column `signal` varchar(250);

#generating signal for tvsmotors1
SET SQL_SAFE_UPDATES=0;

update tvsmotors1 s1 join (
select 
	Date,
    `close price`,
    `20 DAY MA`,
	`50 DAY MA`,
	lag(`20 DAY MA`,1) over(order by Date asc),
	lag(`50 DAY MA`,1) over(order by Date asc),
    `signal`,
    CASE
    WHEN `20 DAY MA` <`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) >lag(`50 DAY MA`,1) over(order by Date asc) THEN "SELL"
    WHEN `20 DAY MA` >`50 DAY MA` and lag(`20 DAY MA`,1) over(order by Date asc) <lag(`50 DAY MA`,1) over(order by Date asc) THEN "BUY"
    ELSE "HOLD"
	END
    as `signal2`
from tvsmotors1
) tsub  on s1.Date = tsub.Date 
set s1.`signal`=tsub.`signal2`;


select count(*) from tvsmotors1 where `signal` = 'SELL';
create table bajaj2 select Date,`close price`,`signal` from bajaj1;
create table infosys2 select Date,`close price`,`signal` from infosys1;
create table tcs2 select Date,`close price`,`signal` from tcs1;
create table eichermotors2 select Date,`close price`,`signal` from eichermotors1;
create table heromotocorps2 select Date,`close price`,`signal` from heromotocorps1;
create table tvsmotors2 select Date,`close price`,`signal` from tvsmotors1;


select * from bajaj2;
##################creeating a function to know the status of a stock on a particular day ########## 
create function extractsignal1(`askingdate` Date)
returns varchar(20) deterministic
return (select `signal` from bajaj2 where Date=`askingdate`);	
select extractsignal1('2018-06-21') ;


select * from bajaj2;






















































